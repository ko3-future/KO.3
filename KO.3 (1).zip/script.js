 // Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyCoYhFjUT5N9ana7hY3h32IeIRZ1o3kR_c",
    authDomain: "YOUR_AUTH_DOMAIN",
    projectId: "ko-3-26588",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};






  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-analytics.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyBt2bcgpsjxWHxMpeJupr-WxqhVUeClEYs",
    authDomain: "project-799d9.firebaseapp.com",
    projectId: "project-799d9",
    storageBucket: "project-799d9.firebasestorage.app",
    messagingSenderId: "243013695067",
    appId: "1:243013695067:web:378f74212e2b73fde9f17e",
    measurementId: "G-B2KE1FS0DX"
  };
  
  

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);







// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

// DOM Elements
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const loginBtn = document.getElementById('loginBtn');
const signUpBtn = document.getElementById('signUpBtn');

// Function to Show Custom Pop-up
function showPopup(message) {
    const popup = document.createElement('div');
    popup.id = 'custom-popup';
    popup.innerHTML = `
        <div class="popup-content">
            <p>${message}</p>
            <button id="closePopupBtn">OK</button>
        </div>
    `;
    document.body.appendChild(popup);

    // Close Pop-up on Button Click
    const closePopupBtn = document.getElementById('closePopupBtn');
    closePopupBtn.addEventListener('click', () => {
        document.body.removeChild(popup);
    });
}

// Login Function
function login() {
    const email = emailInput.value;
    const password = passwordInput.value;

    // Validate Inputs
    if (!email || !password) {
        showPopup("Please fill in all fields."); // Custom pop-up for empty fields
        return;
    }

    // Firebase Login
    auth.signInWithEmailAndPassword(email, password)
        .then((userCredential) => {
            // Redirect to Dashboard
            window.location.href = '/KO.3 future /dashboard.html';
        })
        .catch((error) => {
            // Show error message in custom pop-up
            showPopup("Login failed: " + error.message);
        });
}

// Sign Up Function
function signUp() {
    const email = emailInput.value;
    const password = passwordInput.value;

    // Validate Inputs
    if (!email || !password) {
        showPopup("Please fill in all fields."); // Custom pop-up for empty fields
        return;
    }

    // Firebase Sign Up
    auth.createUserWithEmailAndPassword(email, password)
        .then((userCredential) => {
            // Redirect to Dashboard
            window.location.href = '/KO.3 future /dashboard.html';
        })
        .catch((error) => {
            // Show error message in custom pop-up
            showPopup("Sign up failed: " + error.message);
        });
}

// Event Listeners
if (loginBtn) {
    loginBtn.addEventListener('click', login);
}

if (signUpBtn) {
    signUpBtn.addEventListener('click', signUp);
}