document.addEventListener("DOMContentLoaded", () => {
    const uploadInput = document.getElementById("upload-photo");
    const uploadPlus = document.getElementById("upload-plus");
    const uploadPlusGallery = document.getElementById("upload-plus-gallery");
    const loopContainer = document.getElementById("loop-container");
    const galleryContainer = document.getElementById("gallery-container");
    const memoryBtn = document.getElementById("memory-btn");
    const galleryBtn = document.getElementById("gallery-btn");
    const logoutBtn = document.getElementById("logout-btn");
    const memorySection = document.getElementById("memory-section");
    const gallerySection = document.getElementById("gallery-section");

    // "Your Memory" section pehle show hoga
    memorySection.classList.remove("hidden");
    gallerySection.classList.add("hidden");

    // Section toggle function (No bug)
    function toggleSection(show, hide) {
        if (show && hide) {
            show.classList.remove("hidden");
            hide.classList.add("hidden");
        }
    }

    // Memory button click
    memoryBtn.addEventListener("click", () => toggleSection(memorySection, gallerySection));

    // Gallery button click
    galleryBtn.addEventListener("click", () => toggleSection(gallerySection, memorySection));

    // Upload button triggers file picker
    [uploadPlus, uploadPlusGallery].forEach(button => {
        button.addEventListener("click", () => uploadInput.click());
    });

    // Upload & Error Handling
    uploadInput.addEventListener("change", (event) => {
        const file = event.target.files[0];

        if (!file) {
            alert("⚠️ No file selected! Please choose an image.");
            return;
        }

        if (!file.type.startsWith("image/")) {
            alert("🚫 Invalid file type! Please upload an image.");
            uploadInput.value = "";
            return;
        }

        const reader = new FileReader();
        reader.onload = function (e) {
            const img = document.createElement("img");
            img.src = e.target.result;
            img.classList.add("photo");

            // Loop section: max 10 photos
            if (loopContainer.children.length >= 10) {
                loopContainer.removeChild(loopContainer.children[0]);
            }

            // Add photo to both sections
            const imgClone = img.cloneNode();
            loopContainer.appendChild(img);
            galleryContainer.appendChild(imgClone);

            // Reset input after upload
            uploadInput.value = "";
        };

        reader.onerror = () => alert("❌ Error loading file! Please try again.");
        reader.readAsDataURL(file);
    });

    // Logout button click confirmation
    logoutBtn.addEventListener("click", () => {
        if (confirm("🔴 Are you sure you want to log out?")) {
            alert("✅ Successfully Logged Out!");
            window.location.href = "login.html";
        }
    });
});